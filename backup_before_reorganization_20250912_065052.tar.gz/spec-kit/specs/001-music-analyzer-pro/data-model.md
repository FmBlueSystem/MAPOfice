# Data Model: Music Analysis System

## Entities

### Track
- id: UUID
- path: string (absolute file path)
- title/artist/album: string
- duration_sec: float
- sample_rate: int
- analyzed_at: datetime (nullable)
- enrichment_status: enum(pending, done, failed)

### AnalysisResult
- id: UUID
- track_id: UUID (FK Track)
- bpm: float
- key: string (e.g., C#m)
- energy: float (0..1)
- hamms_vector_id: UUID (FK HAMMSVector)
- created_at: datetime

### HAMMSVector
- id: UUID
- dims: float[12]
- method: string (e.g., chroma_cqt)
- created_at: datetime

### Playlist
- id: UUID
- name: string
- created_at: datetime

### PlaylistItem
- id: UUID
- playlist_id: UUID (FK Playlist)
- track_id: UUID (FK Track)
- position: int
- transition_meta: json (e.g., key change, energy delta)

## Relationships
- Track 1..1 AnalysisResult (latest) — track can have history if needed
- AnalysisResult 1..1 HAMMSVector
- Playlist 1..N PlaylistItem; PlaylistItem N..1 Track

## Notes
- Store historical results in a separate table if re-analysis is frequent.
- Use SQLAlchemy for schema and migrations; start simple, add alembic later.

