# Research: Music Analysis System

## Audio Formats and Libraries
- librosa supports WAV/MP3/OGG via soundfile/audioread; FLAC support via soundfile.
- Decision: support WAV, MP3, FLAC, AAC (AAC via ffmpeg backend if needed).
- Action: verify decoding performance and fallbacks; bundle minimal codecs guidance.

## HAMMS Vector Methodology
- 12D harmonic analysis vector referencing key/chroma features.
- Approach: use chroma_cqt/chroma_stft from librosa; validate stability across genres.
- Benchmark: accuracy vs. MixedInKey/musical key datasets.

## Performance Targets
- p95 < 30s per track on typical desktop (8 cores, 16GB RAM).
- Batch up to 500; concurrency 4 workers.
- Measure: wall-clock, CPU%, memory; cache intermediate features.

## Offline-First + AI Enrichment
- Provider: Anthropic (metadata enrichment). When offline, skip enrichment and mark pending.
- Store enrichment status in DB for retry.

## Data Storage
- SQLite + SQLAlchemy models for Track, AnalysisResult, HAMMSVector, Playlist.
- Migrations: alembic optional; start with simple schema initializer.

## UI/UX (PyQt6)
- Minimal main window: import library, analyze, basic visualizers (VU/spectrogram), compatibility suggestions.
- Progress and cancel controls; error dialogs.

## Testing Strategy
- Fixtures: small audio clips covering diverse keys/BPMs.
- Integration tests for pipelines; unit tests for HAMMS computation and parsers.

