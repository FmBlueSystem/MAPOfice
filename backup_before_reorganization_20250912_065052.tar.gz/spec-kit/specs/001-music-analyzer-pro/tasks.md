# Tasks: Music Analysis System

**Input**: Design documents from `/specs/001-music-analyzer-pro/`
**Prerequisites**: plan.md, research.md, data-model.md, contracts/

## Phase 3.1: Setup
- [ ] T001 Create project structure and audio test fixtures in tests/fixtures/
- [ ] T002 Initialize Python project with PyQt6/librosa/numpy/scipy/soundfile/SQLAlchemy
- [ ] T003 [P] Configure pytest with audio file handling in tests/conftest.py
- [ ] T004 [P] Setup linting and formatting with black/flake8

## Phase 3.2: Tests First (TDD)
- [ ] T005 [P] Integration test full analysis pipeline in tests/integration/test_analysis_flow.py
- [ ] T006 [P] Integration test enrichment pipeline (offline fallback) in tests/integration/test_enrichment.py
- [ ] T007 [P] Integration test compatibility suggestions in tests/integration/test_compatibility.py
- [ ] T008 [P] Integration test playlist generation in tests/integration/test_playlist.py

## Phase 3.3: Core Implementation
- [ ] T011 [P] Track model in src/models/track.py
- [ ] T012 [P] HAMMSVector model in src/models/hamms.py
- [ ] T013 Audio processing library in src/lib/audio_processing.py
- [ ] T014 Track analyzer service in src/services/analyzer.py
- [ ] T015 Compatibility service in src/services/compatibility.py
- [ ] T016 [P] Playlist model in src/models/playlist.py
- [ ] T017 [P] SQLite schema and migrations (SQLAlchemy) in src/models/schema.py
- [ ] T018 Persistence layer (repository simple) in src/services/storage.py

## Phase 3.4: Integration
- [ ] T019 Connect analyzer service to SQLite storage
- [ ] T020 Implement concurrent processing handler (4 workers)
- [ ] T021 Add structured logging
- [ ] T022 [P] CLI interface in src/cli/main.py
- [ ] T023 PyQt6 minimal UI (main window, import library, start analysis) in src/ui/main_window.py
- [ ] T024 [P] Visualizers (VU, spectrogram basic) in src/ui/visualizers/

## Phase 3.5: Polish
- [ ] T025 [P] Unit tests for HAMMS calculation in tests/unit/test_hamms.py
- [ ] T026 [P] Unit tests for audio processing in tests/unit/test_audio.py
- [ ] T027 Performance optimization (<30s per track)
- [ ] T028 [P] UX improvements (progress, cancel, error dialogs)
- [ ] T029 Memory usage optimization (<2GB)

## Dependencies
- Tests (T005-T010) before implementation
- T011, T012 block T013
- T013 blocks T014
- T014 blocks T017, T018
- T019 blocks T020
- All implementation before polish tasks

## Parallel Example
```
# Launch integration tests in parallel:
Task: "Integration test full analysis pipeline in tests/integration/test_analysis_flow.py"
Task: "Integration test enrichment pipeline (offline fallback) in tests/integration/test_enrichment.py"
Task: "Integration test compatibility suggestions in tests/integration/test_compatibility.py"
Task: "Integration test playlist generation in tests/integration/test_playlist.py"
```
