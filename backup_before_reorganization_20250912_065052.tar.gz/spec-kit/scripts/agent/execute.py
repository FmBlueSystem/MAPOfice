#!/usr/bin/env python3
"""
Execute Spec Kit steps using Anthropic Messages API as the LLM backend.

Modes:
  - specify: Render templates/poml/specify.poml and write specs/<branch>/spec.md
  - plan:    Render templates/poml/plan.poml and write specs/<branch>/plan.md
  - tasks:   Render templates/poml/tasks.poml and write specs/<branch>/tasks.md

Environment (.env at repo root):
  ANTHROPIC_API_KEY=...
  ANTHROPIC_MODEL=claude-3-5-sonnet-latest
  ANTHROPIC_BASE_URL=https://api.anthropic.com (optional)
  ANTHROPIC_API_VERSION=2023-06-01 (optional)
  ANTHROPIC_MAX_TOKENS=2000 (optional)

Usage examples:
  python scripts/agent/execute.py specify --feature-dir specs/001-my-feature \
    --user-description "Crear una app kanban simple"

  python scripts/agent/execute.py plan --feature-dir specs/001-my-feature

  python scripts/agent/execute.py tasks --feature-dir specs/001-my-feature
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

import requests

try:
    import poml as poml_api
except Exception:
    print("ERROR: Missing dependency 'poml'. Activate venv and run 'pip install poml'", file=sys.stderr)
    sys.exit(2)


def git_root(start: Path) -> Path:
    cur = start
    for _ in range(10):
        if (cur / ".git").exists():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return start


def load_env_file(path: Path) -> Dict[str, str]:
    env: Dict[str, str] = {}
    if not path.exists():
        return env
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        env[k.strip()] = v.strip()
    return env


def build_spec_kit_context(repo_root: Path, feature_dir: Path | None) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {"project_root": str(repo_root)}
    if feature_dir:
        feature_dir = feature_dir.resolve()
        branch = feature_dir.name
        spec_path = feature_dir / "spec.md"
        plan_path = feature_dir / "plan.md"
        research_path = feature_dir / "research.md"
        data_model_path = feature_dir / "data-model.md"
        contracts_dir = feature_dir / "contracts"
        quickstart_path = feature_dir / "quickstart.md"
        ctx.update(
            {
                "feature_dir": str(feature_dir),
                "branch": branch,
                "spec_path": str(spec_path),
                "plan_path": str(plan_path),
                "research_path": str(research_path),
                "data_model_path": str(data_model_path),
                "contracts_dir": str(contracts_dir),
                "quickstart_path": str(quickstart_path),
                "spec_exists": spec_path.exists(),
                "file_exists_research": research_path.exists(),
                "file_exists_data_model": data_model_path.exists(),
                "file_exists_quickstart": quickstart_path.exists(),
                "dir_exists_contracts": contracts_dir.exists() and any(contracts_dir.iterdir()),
            }
        )
    return ctx


def render_poml(poml_file: Path, context: Dict[str, Any]) -> List[Dict[str, Any]]:
    result = poml_api.poml(
        markup=str(poml_file),
        context=context,
        stylesheet=None,
        chat=True,
        format="message_dict",
    )
    if not isinstance(result, list):
        raise RuntimeError("Unexpected POML output format (expected list of messages)")
    return result


def to_anthropic_payload(messages: List[Dict[str, Any]], model: str, max_tokens: int) -> Dict[str, Any]:
    system_msgs: List[str] = []
    chat_msgs: List[Dict[str, Any]] = []
    for m in messages:
        spk = m.get("speaker") or m.get("role")
        content = m.get("content", "")
        if spk in ("system", "assistant:system"):
            system_msgs.append(str(content))
            continue
        role = "user" if spk in ("human", "user") else "assistant"
        chat_msgs.append({"role": role, "content": content})
    payload: Dict[str, Any] = {
        "model": model,
        "max_tokens": max_tokens,
        "messages": [{"role": m["role"], "content": [{"type": "text", "text": m["content"]}]} for m in chat_msgs],
    }
    if system_msgs:
        payload["system"] = "\n\n".join(system_msgs)
    return payload


def call_anthropic(payload: Dict[str, Any], api_key: str, base_url: str, api_version: str) -> str:
    url = base_url.rstrip("/") + "/v1/messages"
    headers = {
        "x-api-key": api_key,
        "anthropic-version": api_version,
        "content-type": "application/json",
    }
    resp = requests.post(url, headers=headers, data=json.dumps(payload))
    if resp.status_code >= 300:
        raise RuntimeError(f"Anthropic API error: {resp.status_code} {resp.text}")
    data = resp.json()
    # Concatenate text parts from content array
    chunks = []
    for part in data.get("content", []):
        if part.get("type") == "text":
            chunks.append(part.get("text", ""))
    return "".join(chunks).strip()


def main() -> None:
    ap = argparse.ArgumentParser(description="Execute Spec Kit step via Anthropic API")
    ap.add_argument("mode", choices=["specify", "plan", "tasks"], help="Which step to execute")
    ap.add_argument("--feature-dir", required=True, help="Path to specs/<NNN-branch> directory")
    ap.add_argument("--user-description", help="High-level feature description (for specify)")
    ap.add_argument("--user-description-path", help="Path to a file with the feature description (for specify)")
    ap.add_argument("--dry-run", action="store_true", help="Only render prompt; do not call API")
    ap.add_argument("--out", help="Optional file to also write raw LLM output")

    args = ap.parse_args()

    repo_root = git_root(Path.cwd())
    feature_dir = Path(args.feature_dir).resolve()
    feature_dir.mkdir(parents=True, exist_ok=True)

    # Load env
    env_path = repo_root / ".env"
    env = load_env_file(env_path)
    api_key = env.get("ANTHROPIC_API_KEY") or os.getenv("ANTHROPIC_API_KEY")
    model = env.get("ANTHROPIC_MODEL") or os.getenv("ANTHROPIC_MODEL") or "claude-3-5-sonnet-latest"
    base_url = env.get("ANTHROPIC_BASE_URL") or os.getenv("ANTHROPIC_BASE_URL") or "https://api.anthropic.com"
    api_version = env.get("ANTHROPIC_API_VERSION") or os.getenv("ANTHROPIC_API_VERSION") or "2023-06-01"
    max_tokens = int(env.get("ANTHROPIC_MAX_TOKENS") or os.getenv("ANTHROPIC_MAX_TOKENS") or 2000)

    if not args.dry_run and not api_key:
        print("ERROR: Set ANTHROPIC_API_KEY in .env or environment.", file=sys.stderr)
        sys.exit(2)

    # Select POML template and output file
    if args.mode == "specify":
        poml_file = repo_root / "templates/poml/specify.poml"
        target_file = feature_dir / "spec.md"
    elif args.mode == "plan":
        poml_file = repo_root / "templates/poml/plan.poml"
        target_file = feature_dir / "plan.md"
    else:
        poml_file = repo_root / "templates/poml/tasks.poml"
        target_file = feature_dir / "tasks.md"

    # Build context
    ctx = build_spec_kit_context(repo_root, feature_dir)
    if args.mode == "specify":
        if args.user_description_path:
            p = Path(args.user_description_path)
            if not p.exists():
                print(f"ERROR: user description path not found: {p}", file=sys.stderr)
                sys.exit(2)
            ctx["user_description_path"] = str(p)
        elif args.user_description:
            ctx["user_description"] = args.user_description
        else:
            print("ERROR: --user-description or --user-description-path is required for 'specify'", file=sys.stderr)
            sys.exit(2)

    # Render prompt via POML
    messages = render_poml(poml_file, ctx)

    if args.dry_run:
        print(json.dumps(messages, indent=2, ensure_ascii=False))
        return

    # Build and send Anthropic request
    payload = to_anthropic_payload(messages, model=model, max_tokens=max_tokens)
    output_text = call_anthropic(payload, api_key=api_key, base_url=base_url, api_version=api_version)

    # Write files
    target_file.parent.mkdir(parents=True, exist_ok=True)
    target_file.write_text(output_text)
    print(f"Wrote {args.mode} output to {target_file}")

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(output_text)
        print(f"Also wrote raw output to {out_path}")


if __name__ == "__main__":
    main()

