#!/usr/bin/env python3
"""
Render POML prompts with Spec Kit context.

Usage examples:
  python scripts/poml/render.py templates/poml/specify.poml \
    --feature-dir specs/001-my-feature --format message_dict \
    --out prompts/001-my-feature/specify.json --var user_description="Build Taskify..."

  python scripts/poml/render.py templates/poml/plan.poml \
    --feature-dir specs/001-my-feature --format raw > /tmp/plan.md

Requires: pip install poml
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict

try:
    import poml as poml_api
except Exception as e:
    print("ERROR: Missing dependency 'poml'. Install with: pip install poml", file=sys.stderr)
    raise


def git_root(start: Path) -> Path:
    """Resolve repository root via git, fallback to cwd."""
    cur = start
    for _ in range(10):
        if (cur / ".git").exists():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    # Try git command
    try:
        import subprocess

        root = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"], capture_output=True, text=True, check=True
        ).stdout.strip()
        if root:
            return Path(root)
    except Exception:
        pass
    return start


def parse_kv(values: list[str]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for item in values or []:
        if "=" not in item:
            continue
        k, v = item.split("=", 1)
        out[k] = v
    return out


def load_context_arg(arg: str | None) -> Dict[str, Any]:
    if not arg:
        return {}
    p = Path(arg)
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception as e:
            print(f"ERROR: Failed to read JSON context from {p}: {e}", file=sys.stderr)
            sys.exit(2)
    # Fallback: treat as inline JSON string
    try:
        return json.loads(arg)
    except Exception as e:
        print(f"ERROR: --context must be a JSON file path or JSON string: {e}", file=sys.stderr)
        sys.exit(2)


def load_stylesheet_arg(arg: str | None) -> Dict[str, Any] | None:
    if not arg:
        return None
    p = Path(arg)
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception as e:
            print(f"ERROR: Failed to read JSON stylesheet from {p}: {e}", file=sys.stderr)
            sys.exit(2)
    # Fallback inline JSON
    try:
        return json.loads(arg)
    except Exception as e:
        print(f"ERROR: --stylesheet must be a JSON file path or JSON string: {e}", file=sys.stderr)
        sys.exit(2)


def build_spec_kit_context(repo_root: Path, feature_dir: Path | None) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {
        "project_root": str(repo_root),
    }
    if feature_dir:
        feature_dir = feature_dir.resolve()
        branch = feature_dir.name
        spec_path = feature_dir / "spec.md"
        plan_path = feature_dir / "plan.md"
        research_path = feature_dir / "research.md"
        data_model_path = feature_dir / "data-model.md"
        contracts_dir = feature_dir / "contracts"
        quickstart_path = feature_dir / "quickstart.md"

        ctx.update(
            {
                "feature_dir": str(feature_dir),
                "branch": branch,
                "spec_path": str(spec_path),
                "plan_path": str(plan_path),
                "research_path": str(research_path),
                "data_model_path": str(data_model_path),
                "contracts_dir": str(contracts_dir),
                "quickstart_path": str(quickstart_path),
                # existence flags for conditional inclusion in templates
                "spec_exists": spec_path.exists(),
                "file_exists_research": research_path.exists(),
                "file_exists_data_model": data_model_path.exists(),
                "file_exists_quickstart": quickstart_path.exists(),
                "dir_exists_contracts": contracts_dir.exists() and any(contracts_dir.iterdir()),
            }
        )
    return ctx


def main() -> None:
    ap = argparse.ArgumentParser(description="Render a POML file with Spec Kit context")
    ap.add_argument("poml_file", type=str, help="Path to .poml file")
    ap.add_argument("--feature-dir", type=str, help="Path to specs/<NNN-branch> directory")
    ap.add_argument("--context", type=str, help="Additional context (JSON file path or inline JSON)")
    ap.add_argument("--stylesheet", type=str, help="Stylesheet (JSON file path or inline JSON)")
    ap.add_argument(
        "--format",
        type=str,
        default="message_dict",
        choices=[
            "raw",
            "message_dict",
            "dict",
            "openai_chat",
            "langchain",
            "pydantic",
        ],
        help="Output format",
    )
    ap.add_argument("--out", type=str, help="Output file path (optional). Defaults to stdout")
    ap.add_argument("--var", action="append", help="Inject variable KEY=VALUE (repeatable)")
    ap.add_argument("--user-description", type=str, help="High-level feature description string")
    ap.add_argument("--user-description-path", type=str, help="Path to a file with the feature description")

    args = ap.parse_args()

    poml_path = Path(args.poml_file).resolve()
    if not poml_path.exists():
        print(f"ERROR: POML file not found: {poml_path}", file=sys.stderr)
        sys.exit(1)

    cwd = Path.cwd()
    repo_root = git_root(cwd)
    feature_dir = Path(args.feature_dir).resolve() if args.feature_dir else None

    ctx = build_spec_kit_context(repo_root, feature_dir)
    # Merge additional context
    ctx.update(parse_kv(args.var or []))
    ctx.update(load_context_arg(args.context))
    # User description support
    if args.user_description:
        ctx["user_description"] = args.user_description
    if args.user_description_path:
        p = Path(args.user_description_path).resolve()
        if not p.exists():
            print(f"ERROR: --user-description-path not found: {p}", file=sys.stderr)
            sys.exit(2)
        ctx["user_description_path"] = str(p)

    stylesheet = load_stylesheet_arg(args.stylesheet)

    try:
        result = poml_api.poml(
            markup=str(poml_path),
            context=ctx if ctx else None,
            stylesheet=stylesheet,
            chat=True,
            format=args.format,
        )
    except Exception as e:
        print(f"ERROR: Failed to render POML: {e}", file=sys.stderr)
        sys.exit(3)

    # Serialize output depending on type
    out_text: str
    if isinstance(result, (dict, list)):
        out_text = json.dumps(result, indent=2, ensure_ascii=False)
    else:
        out_text = str(result)

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(out_text)
        print(f"Wrote {args.format} to {out_path}")
    else:
        sys.stdout.write(out_text)


if __name__ == "__main__":
    main()

