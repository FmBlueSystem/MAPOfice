# MacBook Pro 13" UI Optimization - Technical Plan

## Architecture Overview

### Current State Analysis
- **Window Size**: 1000x700px (too large for comfortable 13" use)
- **Layout**: 6 vertical sections with excessive padding
- **Content Density**: Low - lots of whitespace
- **Scroll Requirements**: Requires vertical scrolling on 13" displays

### Target State
- **Optimized Window**: 1200x650px (fits 13" screen comfortably)
- **Compact Layout**: Horizontal arrangements where possible
- **Higher Density**: Efficient space usage while maintaining readability
- **Responsive**: Adapts to different window sizes

## Technical Approach

### 1. Responsive Layout System
Create a responsive layout manager that adapts based on available space:

```python
class ResponsiveLayoutManager:
    def __init__(self, window_width: int, window_height: int):
        self.breakpoints = {
            'compact': (0, 1300),      # MacBook Pro 13"
            'medium': (1301, 1600),    # MacBook Pro 15/16" 
            'large': (1601, float('inf'))  # External monitors
        }
```

### 2. Layout Optimization Strategy

#### Vertical Space Reduction
- **Section Consolidation**: Combine related sections horizontally
- **Compact Headers**: Reduce GroupBox header spacing from 20px to 8px
- **Condensed Margins**: Reduce main layout spacing from 15px to 8px
- **Smart Grouping**: Group controls in rows instead of columns

#### Horizontal Space Utilization
- **Two-Column Layout**: Split sections into left/right columns
- **Inline Controls**: Place labels and inputs on same line
- **Compact Buttons**: Smaller button sizes with icons
- **Row-based Grouping**: Arrange related controls horizontally

### 3. Implementation Structure

```
src/ui/
├── layouts/
│   ├── responsive_manager.py     # Main responsive system
│   ├── compact_layout.py         # 13" optimized layouts
│   └── adaptive_components.py    # Size-aware components
└── styles/themes/
    └── compact_theme.py          # 13" specific styling
```

## Component-Specific Optimizations

### Directory Selection (Compact)
```
┌─ Directory ─────────────────────────────────────┐
│ [Browse...] /path/to/audio/files           [📁] │
└─────────────────────────────────────────────────┘
```

### Analysis Controls (Horizontal)
```
┌─ Analysis ──────────────────────────────────────┐
│ [▶ Analyze] [⏹ Stop] [📊 Export] [📋 Copy] │
└─────────────────────────────────────────────────┘
```

### Progress (Condensed)
```
┌─ Progress ──────────────────────────────────────┐
│ Files: ██████████░░ 8/12  │ Stage: BPM ████░ 75%│
│ Current: song.mp3         │ Time: 2m left       │
└─────────────────────────────────────────────────┘
```

### Playlist Tools (Tabbed)
```
┌─ Tools ─────────────────────────────────────────┐
│ [🎵 Compat] [📝 Playlist] [👁 Visualize]        │
│ Seed: /path/song.mp3 [📁] Curve: [↗] Len: [12] │
└─────────────────────────────────────────────────┘
```

## Responsive Breakpoints

### Compact Mode (≤ 1300px width)
- **Two-column main layout**
- **Condensed spacing** (8px instead of 15px)
- **Horizontal control groups**
- **Compact progress indicators**
- **Tabbed secondary features**

### Medium Mode (1301-1600px width)
- **Hybrid layout** (some sections horizontal)
- **Standard spacing** (12px)
- **Grouped controls** with some horizontal arrangements
- **Full progress display**

### Large Mode (>1600px width)
- **Current vertical layout** maintained
- **Full spacing** (15px)
- **All sections fully expanded**
- **Maximum information density**

## Technical Implementation

### 1. Window Size Detection
```python
def detect_layout_mode(self) -> str:
    width = self.width()
    if width <= 1300:
        return 'compact'
    elif width <= 1600:
        return 'medium'
    return 'large'
```

### 2. Dynamic Layout Switching
```python
def apply_responsive_layout(self, mode: str):
    if mode == 'compact':
        self.setup_compact_layout()
    elif mode == 'medium':  
        self.setup_medium_layout()
    else:
        self.setup_large_layout()
```

### 3. Adaptive Styling
```python
# Compact theme with reduced spacing
def get_compact_stylesheet(self) -> str:
    return f"""
    QGroupBox {{
        margin-top: 4px;
        padding-top: 8px;
        font-size: 12px;
    }}
    
    QVBoxLayout {{
        spacing: 6px;
        margin: 6px;
    }}
    """
```

## File Modifications

### Primary Changes
1. **main_window.py**: Add responsive layout detection and switching
2. **responsive_manager.py**: New responsive layout coordinator  
3. **compact_theme.py**: 13" optimized styling
4. **adaptive_components.py**: Size-aware widget wrappers

### Styling Updates
1. **Reduced margins/padding** for compact mode
2. **Smaller font sizes** where appropriate (12px vs 13px)
3. **Compact button styling** with icons
4. **Condensed progress bars** with efficient layouts

## Testing Strategy

### Size Testing
- **1280x800**: Primary 13" MacBook Pro target
- **1440x900**: 13" MacBook Air target  
- **1536x960**: 13" with scaled resolution
- **1024x640**: Minimum functional size

### Content Testing
- **Long file paths**: Ensure truncation works properly
- **Many files**: Test progress with large file counts
- **Extended analysis**: Verify UI remains responsive
- **Window resizing**: Smooth transitions between modes

## Performance Considerations

### Layout Efficiency
- **Single layout switch** on window resize (not continuous)
- **Cached layout components** to avoid recreation
- **Minimal reflow** during responsive transitions
- **Efficient space calculations** using QT layout hints

### Memory Usage
- **Shared components** between layout modes
- **Lazy loading** of less-used responsive elements
- **Cleanup** of unused layout widgets during mode switches