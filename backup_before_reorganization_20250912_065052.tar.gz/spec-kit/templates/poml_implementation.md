# POML Implementation Template: HAMMS v3.0 + OpenAI Integration

```poml
# POML: Prompt Orchestration Markup Language
# Specification-driven implementation with quality gates

@project: music-analyzer-pro
@methodology: spec-kit + bmad + poml
@target: hamms-v3-openai-integration

## Phase 1: Core Implementation Setup

@task("setup-dependencies")
@priority(CRITICAL)
@estimate(30min)
@quality_gate(dependency_check)
{
    # Install new dependencies with version pinning
    pip install openai>=1.0.0 python-dotenv>=1.0.0 plotly>=5.17.0 alembic>=1.12.0
    
    # Validate installations
    python -c "import openai, plotly, alembic; print('✅ All dependencies installed')"
    
    # Create environment configuration
    @template(env_config)
    OPENAI_API_KEY=${USER_PROVIDED_KEY}
    HAMMS_CACHE_SIZE=1000
    AI_BATCH_SIZE=5
    AI_RETRY_ATTEMPTS=3
    AI_TIMEOUT_SECONDS=30
    
    @validation(env_setup)
    assert os.path.exists('.env')
    assert 'OPENAI_API_KEY' in os.environ
}

@task("implement-hamms-v3-core")
@priority(HIGH)
@estimate(3h)
@depends_on(setup-dependencies)
@quality_gate(hamms_calculation_accuracy)
{
    @file("src/analysis/hamms_v3.py")
    @class(HAMMSAnalyzerV3)
    {
        # 12-dimensional analysis with proper weights
        DIMENSION_WEIGHTS = {
            'bpm': 1.3,           # Most important for mixing
            'key': 1.4,           # Critical for harmonic compatibility
            'energy': 1.2,        # Essential for energy curves
            'danceability': 0.9,  # Important for club music
            'valence': 0.8,       # Mood component
            'acousticness': 0.6,  # Production style
            'instrumentalness': 0.5,  # Vocal presence
            'rhythmic_pattern': 1.1,  # Rhythm complexity
            'spectral_centroid': 0.7, # Brightness
            'tempo_stability': 0.9,   # Beat consistency
            'harmonic_complexity': 0.8, # Key complexity
            'dynamic_range': 0.6      # Dynamic variation
        }
        
        @method(calculate_extended_vector)
        @returns(np.ndarray[12])
        @quality_gate(vector_validation)
        def calculate_extended_vector(self, track_data: Dict) -> np.ndarray:
            """
            Calculate 12-dimensional HAMMS vector
            Quality Gates:
            - All dimensions must be 0-1 normalized
            - Vector must have exactly 12 elements
            - No NaN or inf values allowed
            """
            
            # Extract basic features (existing)
            bpm = track_data.get('bmp', 120.0)
            key = track_data.get('key', 'Am')
            energy = track_data.get('energy', 0.5)
            
            # Calculate normalized core dimensions
            norm_bpm = np.clip((bpm - 60) / 140, 0, 1)
            norm_key = self._camelot_to_numeric(key)
            norm_energy = np.clip(energy, 0, 1)
            
            # Calculate extended dimensions
            danceability = self._calculate_danceability(track_data)
            valence = self._calculate_valence(track_data)
            acousticness = self._calculate_acousticness(track_data)
            instrumentalness = self._calculate_instrumentalness(track_data)
            rhythmic_pattern = self._calculate_rhythmic_pattern(track_data)
            spectral_centroid = self._calculate_spectral_centroid(track_data)
            tempo_stability = self._calculate_tempo_stability(track_data)
            harmonic_complexity = self._calculate_harmonic_complexity(track_data)
            dynamic_range = self._calculate_dynamic_range(track_data)
            
            vector = np.array([
                norm_bpm, norm_key, norm_energy,
                danceability, valence, acousticness, instrumentalness,
                rhythmic_pattern, spectral_centroid, tempo_stability,
                harmonic_complexity, dynamic_range
            ])
            
            # Quality gate validation
            @quality_check
            assert len(vector) == 12, "Vector must have 12 dimensions"
            assert np.all((vector >= 0) & (vector <= 1)), "All values must be 0-1"
            assert not np.any(np.isnan(vector)), "No NaN values allowed"
            assert not np.any(np.isinf(vector)), "No infinite values allowed"
            
            return vector
        
        @method(_calculate_danceability)
        @quality_gate(feature_calculation)
        def _calculate_danceability(self, track_data: Dict) -> float:
            """Calculate danceability based on genre and energy"""
            genre = track_data.get('genre', '').lower()
            energy = track_data.get('energy', 0.5)
            bpm = track_data.get('bpm', 120)
            
            # Genre-based danceability mapping
            dance_genres = {
                'house': 0.9, 'techno': 0.95, 'trance': 0.8,
                'edm': 0.9, 'disco': 0.85, 'funk': 0.8,
                'electronic': 0.7, 'dance': 0.9
            }
            
            base_danceability = dance_genres.get(genre, 0.5)
            
            # BPM influence (120-130 BPM optimal for dancing)
            optimal_bpm_range = (110, 140)
            if optimal_bpm_range[0] <= bpm <= optimal_bpm_range[1]:
                bpm_factor = 1.0
            else:
                distance = min(abs(bpm - optimal_bpm_range[0]), abs(bpm - optimal_bmp_range[1]))
                bmp_factor = max(0.3, 1.0 - (distance / 50))
            
            # Energy influence
            danceability = base_danceability * energy * bpm_factor
            
            return np.clip(danceability, 0, 1)
    }
    
    @validation(hamms_v3_implementation)
    # Test with sample data
    sample_track = {
        'bpm': 128, 'key': '8A', 'energy': 0.8, 
        'genre': 'house', 'title': 'Test Track'
    }
    analyzer = HAMMSAnalyzerV3()
    vector = analyzer.calculate_extended_vector(sample_track)
    assert len(vector) == 12
    assert np.all((vector >= 0) & (vector <= 1))
}

@task("implement-openai-integration")
@priority(HIGH)
@estimate(2.5h)
@depends_on(setup-dependencies)
@quality_gate(ai_integration_reliability)
{
    @file("src/analysis/openai_enricher.py")
    @class(OpenAIEnricher)
    {
        @method(__init__)
        def __init__(self, api_key: str = None):
            self.client = openai.OpenAI(
                api_key=api_key or os.getenv('OPENAI_API_KEY')
            )
            self.model = "gpt-4"
            self.cache = {}
            self.rate_limiter = RateLimiter(60, 60)  # 60 requests per minute
        
        @method(enrich_track)
        @quality_gate(ai_response_validation)
        @retry_policy(attempts=3, backoff=exponential)
        @timeout(30s)
        def enrich_track(self, track_data: Dict, hamms_data: Dict) -> Dict:
            """Complete track enrichment using OpenAI GPT-4"""
            
            # Check cache first
            cache_key = self._generate_cache_key(track_data, hamms_data)
            if cache_key in self.cache:
                return self.cache[cache_key]
            
            # Rate limiting
            self.rate_limiter.wait_if_needed()
            
            try:
                # Genre analysis
                genre_result = self.analyze_genre(track_data, hamms_data)
                
                # Mood analysis  
                mood_result = self.analyze_mood(track_data, hamms_data)
                
                # Combine results
                combined_result = {
                    **genre_result,
                    **mood_result,
                    'analysis_timestamp': datetime.utcnow().isoformat(),
                    'ai_version': 'gpt-4',
                    'confidence': min(
                        genre_result.get('confidence', 0.5),
                        mood_result.get('confidence', 0.5)
                    )
                }
                
                # Cache result
                self.cache[cache_key] = combined_result
                
                @quality_check
                assert 'genre' in combined_result, "Genre must be present"
                assert 'mood' in combined_result, "Mood must be present"
                assert 0 <= combined_result['confidence'] <= 1, "Confidence must be 0-1"
                
                return combined_result
                
            except openai.RateLimitError:
                print("⚠️ OpenAI rate limit reached, using fallback")
                return self._fallback_analysis(track_data)
            except openai.APIError as e:
                print(f"⚠️ OpenAI API error: {e}")
                return self._fallback_analysis(track_data)
            except Exception as e:
                print(f"❌ Unexpected error in AI enrichment: {e}")
                return self._fallback_analysis(track_data)
        
        @method(analyze_genre)
        @prompt_template(genre_analysis_prompt)
        def analyze_genre(self, track_data: Dict, hamms_data: Dict) -> Dict:
            """Genre classification using AI with HAMMS context"""
            
            prompt = f"""
            You are an expert music analyst specializing in electronic dance music genres.
            
            Analyze this track and provide genre classification:
            
            Basic Info:
            - Title: {track_data.get('title', 'Unknown')}
            - Artist: {track_data.get('artist', 'Unknown')}
            - BPM: {track_data.get('bpm', 'Unknown')}
            - Key: {track_data.get('key', 'Unknown')}
            - Energy: {track_data.get('energy', 'Unknown')}
            
            HAMMS Analysis (12D):
            - Danceability: {hamms_data.get('vector_12d', [0]*12)[3]:.2f}
            - Valence: {hamms_data.get('vector_12d', [0]*12)[4]:.2f}
            - Acousticness: {hamms_data.get('vector_12d', [0]*12)[5]:.2f}
            - Rhythmic Pattern: {hamms_data.get('vector_12d', [0]*12)[7]:.2f}
            
            Respond ONLY with valid JSON in this format:
            {{
                "genre": "primary_genre",
                "subgenre": "specific_subgenre", 
                "confidence": 0.95,
                "reasoning": "Brief explanation"
            }}
            
            Focus on: House, Techno, Trance, Progressive, Drum & Bass, Dubstep, Ambient
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a professional music genre classifier."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                max_tokens=200
            )
            
            try:
                result = json.loads(response.choices[0].message.content)
                
                @quality_check
                assert 'genre' in result, "Genre field required"
                assert 'confidence' in result, "Confidence field required"
                assert 0 <= result['confidence'] <= 1, "Confidence must be 0-1"
                
                return result
            except json.JSONDecodeError:
                return {
                    "genre": "Electronic", 
                    "subgenre": "Unknown",
                    "confidence": 0.3,
                    "reasoning": "AI response parsing failed"
                }
    }
    
    @validation(openai_integration)
    # Test with API key validation
    enricher = OpenAIEnricher()
    assert enricher.client.api_key is not None
    
    # Test with sample data
    sample_result = enricher.analyze_genre(sample_track, sample_hamms)
    assert 'genre' in sample_result
    assert 'confidence' in sample_result
}

## Phase 2: Database Integration

@task("create-database-models")
@priority(HIGH)
@estimate(2h)
@depends_on(setup-dependencies)
@quality_gate(database_integrity)
{
    @file("src/models/hamms_advanced.py")
    @sqlalchemy_model(HAMMSAdvanced)
    {
        __tablename__ = "hamms_advanced"
        
        track_id = Column(Integer, ForeignKey("tracks.id"), primary_key=True)
        vector_12d = Column(Text)  # JSON: [0.1, 0.8, ...]
        dimension_scores = Column(Text)  # JSON: {"bpm": 0.1, ...}
        similarity_cache = Column(Text)  # Pre-computed similarities
        ml_confidence = Column(Float)
        created_at = Column(DateTime, default=datetime.utcnow)
        
        # Relationship
        track = relationship("TrackORM", back_populates="hamms_advanced")
        
        @validation_method
        def validate_vector_12d(self):
            if self.vector_12d:
                vector = json.loads(self.vector_12d)
                assert len(vector) == 12, "Vector must have 12 dimensions"
                assert all(0 <= v <= 1 for v in vector), "Values must be 0-1"
    }
    
    @file("migrations/001_hamms_v3_tables.py")
    @alembic_migration
    {
        def upgrade():
            # Create hamms_advanced table with proper constraints
            op.create_table(
                'hamms_advanced',
                sa.Column('track_id', sa.Integer, sa.ForeignKey('tracks.id'), primary_key=True),
                sa.Column('vector_12d', sa.Text, nullable=False),
                sa.Column('dimension_scores', sa.Text),
                sa.Column('similarity_cache', sa.Text),
                sa.Column('ml_confidence', sa.Float),
                sa.Column('created_at', sa.DateTime, default=sa.func.current_timestamp())
            )
            
            # Create ai_analysis table
            op.create_table(
                'ai_analysis',
                sa.Column('track_id', sa.Integer, sa.ForeignKey('tracks.id'), primary_key=True),
                sa.Column('genre', sa.String(100)),
                sa.Column('subgenre', sa.String(100)),
                sa.Column('mood', sa.String(100)),
                sa.Column('era', sa.String(50)),
                sa.Column('tags', sa.Text),  # JSON array
                sa.Column('ai_confidence', sa.Float),
                sa.Column('openai_response', sa.Text),
                sa.Column('analysis_date', sa.DateTime, default=sa.func.current_timestamp())
            )
            
            # Performance indices
            op.create_index('idx_hamms_track_id', 'hamms_advanced', ['track_id'])
            op.create_index('idx_ai_track_id', 'ai_analysis', ['track_id'])
            op.create_index('idx_ai_genre', 'ai_analysis', ['genre'])
    }
}

## Phase 3: UI Integration

@task("implement-hamms-radar-chart")
@priority(MEDIUM)  
@estimate(3h)
@depends_on(implement-hamms-v3-core)
@quality_gate(ui_component_functionality)
{
    @file("src/ui/components/hamms_radar.py")
    @qt_component(HAMMSRadarChart)
    {
        @method(__init__)
        def __init__(self):
            super().__init__()
            self.web_view = QWebEngineView()
            self.setup_ui()
        
        @method(update_hamms_data)
        @quality_gate(chart_rendering)
        def update_hamms_data(self, hamms_vector: List[float], dimension_names: List[str]):
            """Update radar chart with new HAMMS data"""
            
            @validation
            assert len(hamms_vector) == 12, "Must have 12 dimensions"
            assert len(dimension_names) == 12, "Must have 12 labels"
            assert all(0 <= v <= 1 for v in hamms_vector), "Values must be normalized"
            
            # Create Plotly radar chart
            fig = go.Figure(data=go.Scatterpolar(
                r=hamms_vector,
                theta=dimension_names,
                fill='toself',
                name='HAMMS v3.0',
                fillcolor='rgba(0, 150, 255, 0.3)',
                line=dict(color='rgb(0, 150, 255)', width=2)
            ))
            
            fig.update_layout(
                polar=dict(
                    radialaxis=dict(
                        visible=True,
                        range=[0, 1],
                        tickvals=[0, 0.25, 0.5, 0.75, 1],
                        ticktext=['0', '0.25', '0.5', '0.75', '1']
                    )
                ),
                title="HAMMS v3.0 Analysis",
                font=dict(size=10)
            )
            
            html = fig.to_html(include_plotlyjs='cdn')
            self.web_view.setHtml(html)
            
            @quality_check
            # Verify chart renders without errors
            assert self.web_view.url().toString() != "about:blank"
    }
}

## Phase 4: Integration & Testing

@task("integrate-enhanced-pipeline")
@priority(HIGH)
@estimate(2h)
@depends_on([implement-hamms-v3-core, implement-openai-integration, create-database-models])
@quality_gate(pipeline_integration)
{
    @file("src/services/enhanced_analyzer.py")
    @pipeline(enhanced_analysis_pipeline)
    {
        def enhanced_analysis_pipeline(file_path: str) -> Dict:
            """Complete analysis pipeline with HAMMS v3.0 + AI"""
            
            results = {
                'file_path': file_path,
                'timestamp': datetime.utcnow().isoformat(),
                'success': False,
                'errors': []
            }
            
            try:
                # 1. Basic audio analysis (existing)
                basic_results = analyze_track(file_path)
                results['basic'] = basic_results
                
                # 2. HAMMS v3.0 calculation
                hamms_analyzer = HAMMSAnalyzerV3()
                hamms_vector = hamms_analyzer.calculate_extended_vector(basic_results)
                hamms_data = {
                    'vector_12d': hamms_vector.tolist(),
                    'dimension_scores': dict(zip(DIMENSION_NAMES, hamms_vector)),
                    'ml_confidence': 0.95
                }
                results['hamms_v3'] = hamms_data
                
                # 3. AI enrichment (with fallback)
                try:
                    ai_enricher = OpenAIEnricher()
                    ai_results = ai_enricher.enrich_track(basic_results, hamms_data)
                    results['ai_analysis'] = ai_results
                except Exception as e:
                    print(f"⚠️ AI enrichment failed, using fallback: {e}")
                    results['ai_analysis'] = {
                        'genre': 'Electronic',
                        'mood': 'Unknown',
                        'confidence': 0.1,
                        'error': str(e)
                    }
                
                # 4. Store all results
                storage = Storage.from_path("data/music.db")
                
                # Store/update basic track
                track = storage.upsert_track(file_path)
                
                # Store HAMMS advanced
                storage.save_hamms_advanced(track.id, hamms_data)
                
                # Store AI analysis
                storage.save_ai_analysis(track.id, results['ai_analysis'])
                
                results['success'] = True
                results['track_id'] = track.id
                
                @quality_check
                assert results['success'] == True
                assert 'track_id' in results
                assert len(results.get('errors', [])) == 0
                
                return results
                
            except Exception as e:
                results['errors'].append(str(e))
                print(f"❌ Enhanced analysis failed: {e}")
                return results
    }
}

@task("comprehensive-testing")
@priority(HIGH)
@estimate(1h)
@depends_on([integrate-enhanced-pipeline])
@quality_gate(comprehensive_validation)
{
    @test_suite(hamms_v3_tests)
    {
        def test_hamms_v3_calculation():
            """Test HAMMS v3.0 vector calculation"""
            analyzer = HAMMSAnalyzerV3()
            
            sample_data = {
                'bpm': 128, 'key': '8A', 'energy': 0.8,
                'genre': 'house', 'title': 'Test Track'
            }
            
            vector = analyzer.calculate_extended_vector(sample_data)
            
            assert len(vector) == 12
            assert np.all((vector >= 0) & (vector <= 1))
            assert not np.any(np.isnan(vector))
            
            # Test specific dimensions
            assert vector[0] > 0  # BPM should be normalized > 0
            assert vector[2] == 0.8  # Energy should match input
        
        def test_openai_integration():
            """Test OpenAI integration with fallback"""
            enricher = OpenAIEnricher()
            
            # Test with valid data
            result = enricher.enrich_track(sample_data, sample_hamms)
            assert 'genre' in result
            assert 'confidence' in result
            assert 0 <= result['confidence'] <= 1
        
        def test_enhanced_pipeline():
            """Test complete enhanced pipeline"""
            # Create temporary test file
            test_file = create_test_audio_file()
            
            results = enhanced_analysis_pipeline(test_file)
            
            assert results['success'] == True
            assert 'hamms_v3' in results
            assert 'ai_analysis' in results
            assert len(results['hamms_v3']['vector_12d']) == 12
    }
    
    @performance_test
    {
        def test_performance_requirements():
            """Verify performance meets requirements"""
            
            # HAMMS calculation should be <500ms
            start_time = time.time()
            analyzer.calculate_extended_vector(sample_data)
            hamms_time = time.time() - start_time
            assert hamms_time < 0.5, f"HAMMS calculation took {hamms_time}s"
            
            # Database queries should be <100ms
            start_time = time.time()
            storage.get_track_by_path(test_path)
            db_time = time.time() - start_time
            assert db_time < 0.1, f"DB query took {db_time}s"
    }
}

## Final Quality Gates

@quality_gate(final_validation)
@depends_on([comprehensive-testing])
{
    # Run all existing quality gates
    run_quality_gates()
    
    # Verify new functionality works
    assert hamms_v3_working()
    assert openai_integration_working()  
    assert ui_components_functional()
    assert database_migrations_successful()
    
    # Performance validation
    assert performance_requirements_met()
    
    # Documentation updated
    assert documentation_updated()
    
    print("✅ All quality gates passed - Implementation complete!")
}
```

**POML Implementation Status**: ✅ READY FOR EXECUTION  
**Estimated Completion**: 20 hours  
**Quality Gates**: 15 checkpoints  
**Success Criteria**: All gates must pass green