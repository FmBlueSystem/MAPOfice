POML Templates for Spec Kit

Overview
- These POML files orchestrate structured prompts for the Spec-Driven Development (SDD) flow.
- Use them with the Python POML SDK and the helper script at `scripts/poml/render.py`.

Templates
- specify.poml: Drafts a business-facing specification (`spec.md`) from a high-level description.
- plan.poml: Produces an implementation plan (`plan.md`) guided by the Constitution and spec.
- tasks.poml: Breaks the plan into executable tasks (`tasks.md`) with TDD-first ordering.

Quick Start
1) Ensure dependencies are installed:
   - Activate venv: `source .venv/bin/activate`
   - `pip install poml` (already included in setup instructions)
2) Render a prompt for your current feature directory:
   - `python scripts/poml/render.py templates/poml/specify.poml --feature-dir specs/NNN-your-feature --format message_dict --out prompts/NNN-your-feature/specify.json`
3) Feed the rendered prompt into your agent (Claude, Gemini, or Copilot) to execute the step.

Notes
- The templates reference repository files (e.g., `memory/constitution.md`, `templates/*`) using variables filled by `--feature-dir`.
- You can inject additional variables with repeated `--var KEY=VALUE` flags.
- Choose output format suitable for your tooling: `raw`, `message_dict`, `openai_chat`, etc.

