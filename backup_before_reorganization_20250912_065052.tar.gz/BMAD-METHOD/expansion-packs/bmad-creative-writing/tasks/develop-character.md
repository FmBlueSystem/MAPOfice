<!-- Powered by BMAD™ Core -->

# ------------------------------------------------------------

# 3. Develop Character

# ------------------------------------------------------------

---

task:
id: develop-character
name: Develop Character
description: Produce rich character profiles with goals, flaws, arcs, and voice notes.
persona_default: character-psychologist
inputs:

- concept-brief.md
  steps:
- Identify protagonist(s), antagonist(s), key side characters.
- For each, fill character-profile-tmpl.
- Offer advanced‑elicitation for each profile.
  output: characters.md
  ...
