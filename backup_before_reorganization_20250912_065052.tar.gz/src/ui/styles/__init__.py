"""UI Styling system for Music Analyzer Pro."""

from .style_manager import StyleManager

__all__ = ['StyleManager']