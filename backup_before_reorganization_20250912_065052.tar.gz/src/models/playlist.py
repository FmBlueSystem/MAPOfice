class Playlist:
    """Represents a playlist and its items.

    Placeholder for TDD; implementation will follow.
    """

    def __init__(self, name: str):
        raise NotImplementedError("Playlist not implemented yet")

