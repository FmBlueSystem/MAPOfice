"""Progress callback interface for audio analysis operations."""

from typing import Protocol, Optional
from ..models.progress import AnalysisStage


class ProgressCallback(Protocol):
    """Protocol for progress callback functions during audio analysis.
    
    This callback interface allows audio processing functions to report
    their progress back to UI components or other tracking systems.
    """
    
    def __call__(
        self, 
        stage: AnalysisStage, 
        progress: float, 
        message: str,
        file_path: Optional[str] = None
    ) -> None:
        """Report progress for a specific analysis stage.
        
        Args:
            stage: Current analysis stage being processed
            progress: Progress within stage (0.0 to 1.0)
            message: Human-readable progress message
            file_path: Optional file path being analyzed
        """
        ...


def create_no_op_callback() -> ProgressCallback:
    """Create a no-operation callback that does nothing.
    
    Useful for backward compatibility when progress tracking is not needed.
    """
    def no_op_callback(stage: AnalysisStage, progress: float, message: str, file_path: Optional[str] = None) -> None:
        pass
    
    return no_op_callback


def create_logging_callback(logger_func=None) -> ProgressCallback:
    """Create a callback that logs progress messages.
    
    Args:
        logger_func: Function to use for logging (defaults to print)
    
    Returns:
        Progress callback that logs messages
    """
    if logger_func is None:
        logger_func = print
    
    def logging_callback(stage: AnalysisStage, progress: float, message: str, file_path: Optional[str] = None) -> None:
        file_info = f" [{file_path}]" if file_path else ""
        logger_func(f"[{stage.value}] {progress:.1%}: {message}{file_info}")
    
    return logging_callback


class ProgressCallbackComposer:
    """Compose multiple progress callbacks into a single callback.
    
    Useful when you want to report progress to multiple destinations
    (e.g., UI updates + logging + metrics collection).
    """
    
    def __init__(self, *callbacks: ProgressCallback):
        self.callbacks = list(callbacks)
    
    def add_callback(self, callback: ProgressCallback) -> None:
        """Add another callback to the composition."""
        self.callbacks.append(callback)
    
    def __call__(
        self, 
        stage: AnalysisStage, 
        progress: float, 
        message: str,
        file_path: Optional[str] = None
    ) -> None:
        """Call all composed callbacks with the same arguments."""
        for callback in self.callbacks:
            try:
                callback(stage, progress, message, file_path)
            except Exception as e:
                # Don't let callback errors break the analysis
                # In production, this might log to an error handler
                print(f"Progress callback error: {e}")


def create_pyqt_signal_callback(
    stage_progress_signal,
    stage_changed_signal,
    time_estimate_signal,
    time_estimator
) -> ProgressCallback:
    """Create a callback that emits PyQt signals for UI updates.
    
    Args:
        stage_progress_signal: PyQt signal for stage progress updates
        stage_changed_signal: PyQt signal for stage changes  
        time_estimate_signal: PyQt signal for time estimates
        time_estimator: TimeEstimator instance for timing calculations
    
    Returns:
        Progress callback that emits PyQt signals
    """
    current_stage = None
    
    def pyqt_callback(
        stage: AnalysisStage, 
        progress: float, 
        message: str,
        file_path: Optional[str] = None
    ) -> None:
        nonlocal current_stage
        
        # Emit stage progress
        stage_progress_signal.emit(stage, progress, message)
        
        # Emit stage change if stage changed
        if current_stage != stage:
            current_stage = stage
            filename = file_path.split('/')[-1] if file_path else "Unknown file"
            stage_changed_signal.emit(stage, filename)
        
        # Emit time estimate if time estimator available
        if time_estimator:
            elapsed = time_estimator.get_elapsed_time()
            remaining = time_estimator.get_remaining_time_estimate(stage, progress, 0)
            if remaining is not None:
                time_estimate_signal.emit(elapsed, remaining)
    
    return pyqt_callback