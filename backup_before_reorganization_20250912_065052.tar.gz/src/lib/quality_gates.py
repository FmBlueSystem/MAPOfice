"""Quality Gates Framework for Music Analyzer Pro

Provides centralized quality control mechanisms across all services.
Based on lessons learned from BPM tolerance failures and silent exception handling.
"""

from __future__ import annotations

import functools
import logging
from typing import Dict, Any, List, Callable, Optional
from dataclasses import dataclass
from enum import Enum


class QualityLevel(Enum):
    """Quality gate enforcement levels."""
    STRICT = "strict"      # Fail fast on any violation
    WARNING = "warning"    # Log warnings but continue
    SILENT = "silent"      # No enforcement (not recommended)


@dataclass
class QualityViolation:
    """Represents a quality gate violation."""
    gate_name: str
    severity: str
    message: str
    context: Dict[str, Any]


class QualityGateRegistry:
    """Central registry for quality gate enforcement."""
    
    def __init__(self, default_level: QualityLevel = QualityLevel.STRICT):
        self.default_level = default_level
        self.violations: List[QualityViolation] = []
        self.logger = logging.getLogger(__name__)
    
    def validate_track_data(self, track: Dict[str, Any], context: str = "") -> bool:
        """Validate track data structure and content."""
        violations = []
        
        # Required fields check
        required_fields = {"path", "bpm", "key", "energy", "hamms"}
        missing_fields = required_fields - set(track.keys())
        if missing_fields:
            violations.append(QualityViolation(
                gate_name="track_data_structure",
                severity="ERROR",
                message=f"Missing required fields: {missing_fields}",
                context={"path": track.get("path", "unknown"), "context": context}
            ))
        
        # BPM validation
        bpm = track.get("bpm")
        if bpm is not None and (not isinstance(bpm, (int, float)) or bpm <= 0 or bpm > 300):
            violations.append(QualityViolation(
                gate_name="bpm_validation",
                severity="ERROR", 
                message=f"Invalid BPM value: {bpm}",
                context={"path": track.get("path", "unknown"), "bpm": bpm}
            ))
        
        # HAMMS validation
        hamms = track.get("hamms")
        if hamms is not None:
            if not isinstance(hamms, list) or len(hamms) != 12:
                violations.append(QualityViolation(
                    gate_name="hamms_validation",
                    severity="ERROR",
                    message=f"HAMMS must be 12-element list, got {type(hamms)} with length {len(hamms) if isinstance(hamms, list) else 'N/A'}",
                    context={"path": track.get("path", "unknown")}
                ))
            elif not all(isinstance(x, (int, float)) for x in hamms):
                violations.append(QualityViolation(
                    gate_name="hamms_validation",
                    severity="ERROR",
                    message="HAMMS vector must contain only numeric values",
                    context={"path": track.get("path", "unknown")}
                ))
        
        # Energy validation
        energy = track.get("energy")
        if energy is not None and (not isinstance(energy, (int, float)) or not 0 <= energy <= 1):
            violations.append(QualityViolation(
                gate_name="energy_validation",
                severity="ERROR",
                message=f"Energy must be in range [0,1], got {energy}",
                context={"path": track.get("path", "unknown"), "energy": energy}
            ))
        
        # Record violations
        self.violations.extend(violations)
        
        # Handle violations based on quality level
        if violations and self.default_level == QualityLevel.STRICT:
            error_msg = f"Quality gate violations in {context}:\n"
            for v in violations:
                error_msg += f"  - {v.gate_name}: {v.message}\n"
            raise ValueError(error_msg.strip())
        elif violations and self.default_level == QualityLevel.WARNING:
            for v in violations:
                self.logger.warning(f"Quality Gate [{v.gate_name}]: {v.message}")
        
        return len(violations) == 0
    
    def validate_playlist_integrity(self, playlist: List[Dict[str, Any]], tolerance: float) -> bool:
        """Validate playlist meets BPM tolerance and data integrity requirements."""
        violations = []
        
        if not isinstance(playlist, list):
            violations.append(QualityViolation(
                gate_name="playlist_structure",
                severity="ERROR",
                message=f"Playlist must be list, got {type(playlist)}",
                context={}
            ))
        
        if len(playlist) < 1:
            violations.append(QualityViolation(
                gate_name="playlist_length",
                severity="ERROR",
                message="Playlist cannot be empty",
                context={}
            ))
        
        # Validate each track in playlist
        for i, track in enumerate(playlist):
            if not self.validate_track_data(track, f"playlist_track_{i}"):
                continue  # Violations already recorded
            
            # BPM requirement for playlist tracks
            if not track.get("bpm"):
                violations.append(QualityViolation(
                    gate_name="playlist_bpm_requirement",
                    severity="ERROR",
                    message=f"Playlist track missing BPM: position {i}",
                    context={"path": track.get("path", "unknown"), "position": i}
                ))
        
        # Validate BPM transitions
        for i in range(1, len(playlist)):
            prev_bpm = playlist[i-1].get("bpm")
            curr_bpm = playlist[i].get("bpm")
            
            if prev_bpm and curr_bpm:
                diff_pct = abs(curr_bpm - prev_bpm) / prev_bpm
                if diff_pct > tolerance:
                    # Check if it passes double/half tempo rules
                    from src.services.compatibility import bpm_within_tolerance
                    if not bpm_within_tolerance(prev_bpm, curr_bpm, tolerance):
                        violations.append(QualityViolation(
                            gate_name="bpm_tolerance_violation",
                            severity="ERROR",
                            message=f"BPM transition violates tolerance: {prev_bpm:.1f} → {curr_bpm:.1f} ({diff_pct*100:.1f}% > {tolerance*100:.1f}%)",
                            context={"position": i, "prev_bpm": prev_bpm, "curr_bpm": curr_bpm}
                        ))
        
        # Record violations and handle
        self.violations.extend(violations)
        
        if violations and self.default_level == QualityLevel.STRICT:
            error_msg = "Playlist quality gate violations:\n"
            for v in violations:
                error_msg += f"  - {v.gate_name}: {v.message}\n"
            raise ValueError(error_msg.strip())
        elif violations and self.default_level == QualityLevel.WARNING:
            for v in violations:
                self.logger.warning(f"Quality Gate [{v.gate_name}]: {v.message}")
        
        return len(violations) == 0
    
    def get_violation_report(self) -> Dict[str, Any]:
        """Get comprehensive report of all quality violations."""
        violations_by_gate = {}
        for violation in self.violations:
            gate = violation.gate_name
            if gate not in violations_by_gate:
                violations_by_gate[gate] = []
            violations_by_gate[gate].append(violation)
        
        return {
            "total_violations": len(self.violations),
            "violations_by_gate": violations_by_gate,
            "quality_score": max(0, 100 - len(self.violations) * 5),  # Penalize 5 points per violation
            "compliance_level": "COMPLIANT" if len(self.violations) == 0 else "NON_COMPLIANT"
        }
    
    def clear_violations(self):
        """Clear violation history."""
        self.violations.clear()


# Global quality gate instance
quality_gates = QualityGateRegistry()


def enforce_quality_gate(gate_name: str, level: QualityLevel = None):
    """Decorator to enforce quality gates on functions."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            gate_level = level or quality_gates.default_level
            
            try:
                result = func(*args, **kwargs)
                
                # Validate result based on function name patterns
                if 'playlist' in func.__name__.lower() and isinstance(result, list):
                    tolerance = kwargs.get('bpm_tolerance', 0.08)
                    quality_gates.validate_playlist_integrity(result, tolerance)
                elif 'track' in func.__name__.lower() and isinstance(result, dict):
                    quality_gates.validate_track_data(result, func.__name__)
                
                return result
                
            except Exception as e:
                if gate_level == QualityLevel.STRICT:
                    raise
                elif gate_level == QualityLevel.WARNING:
                    quality_gates.logger.warning(f"Quality gate exception in {func.__name__}: {e}")
                    return None
                else:  # SILENT
                    return None
        
        return wrapper
    return decorator